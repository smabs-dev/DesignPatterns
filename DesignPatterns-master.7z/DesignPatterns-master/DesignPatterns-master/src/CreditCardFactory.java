
public interface CreditCardFactory {

    CreditCard createCreditCard(String[] cardInfo);
}
